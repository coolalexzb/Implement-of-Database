Group member:
Zijie Song (zs22)
Bo Zheng (bz30)

SortingTime.png is the screenshot for sorting time. The process takes about 9 seconds.